<?php

return [
    'twitter' => [
        'consumer_key'        => 'YOUR_CONSUMER_KEY',
        'consumer_secret'     => 'YOUR_CONSUMER_SECRET',
        'access_token'        => 'YOUR_ACCESS_TOKEN',
        'access_token_secret' => 'YOUR_ACCESS_TOKEN_SECRET',
    ],
    'meta' => [
        'app_id'           => '952268383945804', 
        'app_secret'       => '06510d978bdc1fbd3d11733839c94442', 
        'instagram_app_id' => '1502480454733843',
        'instagram_secret' => 'a8d346c2a09d6cd6b32f612474314234',
        'redirect_uri'     => 'https://graph-api.my-react.com/callback.php', 
        'scopes' => [
            'public_profile',
            'pages_show_list',
            'pages_manage_metadata',
            'pages_read_engagement',
            'pages_manage_posts',
            'instagram_basic',
            'instagram_content_publish'
        ],
    ]
];